<!-- Bootstrap core CSS -->
<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- Custom styles for this template -->
<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/fonts/antonio-exotic/stylesheet.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/lightbox.min.css')); ?>">
<link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/lightbox-plus-jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/instafeed.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>" type="text/javascript"></script><?php /**PATH C:\Users\PC AL KINDI\Documents\alkindi-royale\resources\views/Components/css.blade.php ENDPATH**/ ?>