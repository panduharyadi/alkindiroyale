<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="images/icons/favicon.png"/>
        <title><?php echo $__env->yieldContent('title'); ?></title>

        <?php echo $__env->make('Components.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    </head>
    <body>
        <div id="page">
            <!---header top---->
                <?php echo $__env->make('Components/headBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--header--->

            
                <?php echo $__env->make('Components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            


            <!--end-->
            <?php echo $__env->yieldContent('content'); ?>

            <!---footer--->
                <?php echo $__env->make('Components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!--back to top--->
            <a style="display: none;" href="javascript:void(0);" class="scrollTop back-to-top" id="back-to-top">
                <span><i aria-hidden="true" class="fa fa-angle-up fa-lg"></i></span>
                <span>Top</span>
            </a>

        </div>
    </body>
</html><?php /**PATH C:\Users\PC AL KINDI\Documents\alkindi-royale\resources\views/Layout/layout.blade.php ENDPATH**/ ?>