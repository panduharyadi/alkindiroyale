<div class="top-header">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <a href="#"> </a>
                 <div class="info-block"><i class="fa fa-map"></i>Jakarta Selatan</div>
            </div>
            <div class="col-md-6">
                <div class="social-grid">
                    <ul class="list-unstyled text-right">
                        <li><a><i class="fa fa-facebook"></i></a></li>
                        <li><a><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>